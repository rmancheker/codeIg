<?php

if(!defined('BASEPATH'))exit('No Access');
class crud extends CI_Controller{
	function index(){
		$this->load->view('register');
	}

	function register_action(){
		$result = $this->input->post();
		print_r($result);
	}

	function userdata(){
		$dataarr = $this->input->post();
		//$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]');
		$this->form_validation->set_rules('mobile','mobile','trim|integer|required|exact_length[10]');
		$this->form_validation->set_rules('email','email','trim|valid_email|required|is_unique[user.email]');
		$this->form_validation->set_rules('pwd', 'password', 'trim|required|min_length[5]|matches[cnfpwd]|alpha_numeric');

		if($this->form_validation->run()==false){
			echo validation_errors();
		}else{
			$this->load->model('register_model');
			unset($dataarr['cnfpwd']);
			$dataarr['pwd'] = sha1($dataarr['pwd']);
			//pre($dataarr);
			//insert function
			$retval = $this->register_model->insert_data($dataarr);
			if($retval == 1){
				echo "Data added";
			}else{
				echo "Error is saving data";
			}

		}	

	}

}
//umeshpatel120@gmail.com

?>