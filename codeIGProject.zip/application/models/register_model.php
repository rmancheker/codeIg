<?php
if(!defined('BASEPATH'))exit('No Access');
class register_model extends CI_Model{
	function insert_data($data){
		return $this->db->insert('user',$data);
	}


}

?>
