$(document).ready(function(){
	$(".btn-default").click(function() {
		
		$.ajax({
			type:"POST",
			url:path+"crud/userdata",
			data:$("#user_form").serialize(),

			success:function(val){
				$(".error").html(val);
			}
		})

	});
});